(function () {
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char];
    });
  }

  function orderText(order) {
    var type = order.type === 'pickup' ? 'Самовывоз' : 'Доставка';
    var payment = order.pay === 'card' ? 'Картой' : 'Наличными';
    var address = order.type === 'pickup' ? 'Не требуется' : order.address;
    return [
      '<b>Новый заказ ' + escapeHtml(order.num) + '</b>',
      '',
      '<b>Клиент:</b> ' + escapeHtml(order.name),
      '<b>Телефон:</b> ' + escapeHtml(order.phone),
      '<b>Получение:</b> ' + type,
      '<b>Адрес:</b> ' + escapeHtml(address),
      '<b>Оплата:</b> ' + payment,
      order.comment ? '<b>Комментарий:</b> ' + escapeHtml(order.comment) : '',
      '',
      '<b>Состав заказа:</b>',
      (order.items || []).map(escapeHtml).join('\n'),
      '',
      '<b>Сумма:</b> ' + escapeHtml(order.subtotal),
      '<b>Доставка:</b> ' + escapeHtml(order.delivery),
      '<b>Итого:</b> ' + escapeHtml(order.total)
    ].filter(Boolean).join('\n');
  }

  window.sendOrderToTelegram = async function (order) {
    var config = window.TELEGRAM_CONFIG || {};
    var url = String(config.orderApiUrl || '');
    if (!url || url.indexOf('<ORDER_FUNCTION_ID>') !== -1) {
      console.error('Telegram order endpoint is not configured.');
      return false;
    }

    try {
      var response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: orderText(order), hp: order.hp || '', elapsed: Number(order.elapsed) || 0 })
      });
      var data = await response.json().catch(function () { return null; });
      return Boolean(response.ok && data && data.ok === true);
    } catch (error) {
      console.error('Telegram order request failed:', error);
      return false;
    }
  };
})();
