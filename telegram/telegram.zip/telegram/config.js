/*
  Укажите здесь только публичный URL уже существующей Yandex Cloud Function заказов.
  Не добавляйте сюда токен Telegram, chat ID, proxy secret или другие секреты.
*/
window.TELEGRAM_CONFIG = {
  orderApiUrl: 'https://functions.yandexcloud.net/<ORDER_FUNCTION_ID>'
};
